<?php
/**
 * @author Adrián López Pascual
 */
$num1 = readline("Dime el número a redondear ");
$redondeo = round($num1);
echo "El número redondeado es: " . $redondeo;
echo "\n";

?>