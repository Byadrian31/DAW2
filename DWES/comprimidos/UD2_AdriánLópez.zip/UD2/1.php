<?php
/**
 * @author Adrián López Pascual
 */
$nombre = readline("Dime tu nombre ");
echo "Hola $nombre, encantado de conocerte \n";
?>