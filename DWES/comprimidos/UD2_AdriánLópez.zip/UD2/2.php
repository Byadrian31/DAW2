<?php
/**
 * @author Adrián López Pascual
 */
$nombre = readline("Dime tu nombre ");
$texto = "Hola " . $nombre . ", encantado de conocerte \n";
echo $texto;
?>