<?php
/**
 * @author Adrián López Pascual
 */
$ale = rand(10,90);
echo "La cantidad es de " . $ale;

echo " \n";
?>