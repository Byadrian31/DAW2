@extends('plantilla')

@section('titulo', 'Inicio del proyecto BLOG')

@section('contenido')
    <h1>Bienvenido/a al blog de Adrian Lopez</h1>
@endsection
