<?php
const MYSQL_ROOT="root";
const MYSQL_ROOT_PASSWORD="dbrootpass";
const MYSQL_USER="dbuser";
const MYSQL_PASSWORD="dbpass";
const USERNAME="dwes";
const PASSWORD="dbdwespass";
const HOST="localhost:33006";
?>