<?php
/**
 * @author Adrián López Pascual
 */
$num = readline("Dime el número: ");
$longitud = strlen($num);
echo $longitud . "\n";
?>